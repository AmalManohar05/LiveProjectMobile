
# TestAutomation.Mobile.Core

# Introduction
TestAutomation.Mobile.Core is a framework based on .NET 8 designed in order to facilitate mobile actions in a testing enviorment.

# Help & Contribute
In case you are going to integrate the framework and you need help for the integration, please contact Test Automation Team.
For contribution, please contact Test Automation Team.

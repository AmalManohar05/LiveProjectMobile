﻿using NUnit.Framework;
using OpenQA.Selenium.Appium;
using OpenQA.Selenium.Appium.Android;
using OpenQA.Selenium.Appium.Service;
using OpenQA.Selenium.DevTools.V126.Browser;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TestAutomation.Mobile.Core.MobileCore.DriverFactory;

namespace TestAutomation.Mobile.Core.MobileCore.Core
{

    public class TestBase
    {
        public AppiumDriver? _appDriver;
        public void DriverSetup()
        {
            try
            {
                _appDriver = TestContext.Parameters["platformName"]!.Equals("android", StringComparison.OrdinalIgnoreCase) ? new AndroidDriverFactory().GetDriver().InitializeDriver() : new IosDriverFactory().GetDriver().InitializeDriver();
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }
    }
}
﻿using OpenQA.Selenium.Appium;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TestAutomation.Mobile.Core.MobileCore.Core
{
    public class PageBase
    {
        public AppiumDriver? _appDriver;
        public PageBase(AppiumDriver _appDriver)
        {
            this._appDriver = _appDriver;
        }

    }
}
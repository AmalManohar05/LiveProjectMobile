﻿using NUnit.Framework;
using OpenQA.Selenium.Appium.Service;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using TestAutomation.Mobile.Core.MobileCore.Utilities;

namespace TestAutomation.Mobile.Core.MobileCore.Core
{
    /// <summary>
    /// Constructs an appium service instance
    /// </summary>
    /// <returns>Appium local service</returns>
    public class ServiceBuilder
    {
        private AppiumLocalService? appiumService;

        public AppiumLocalService BuildAppiumService()
        {
            appiumService = new AppiumServiceBuilder()
                .WithAppiumJS(new FileInfo(Path.Combine(
                    Environment.GetFolderPath(Environment.SpecialFolder.UserProfile),
                    "AppData", "Roaming", "npm", "node_modules", "appium", "build", "lib", "main.js")))
                .WithIPAddress(SystemUtils.GetLocalIPAddress())
                .UsingPort(int.Parse(TestContext.Parameters["appiumPort"]!))
                .Build();
            return appiumService;
        }
    }
}
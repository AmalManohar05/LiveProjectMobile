﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TestAutomation.Mobile.Core.MobileCore.Utilities
{
    /// <summary>
    /// Enums for automation framework.
    /// </summary>
    public class Locator
    {
        /// <summary>
        /// Enumerators for locator types.
        /// </summary>
        public enum LocatorType
        {
            /// <summary>
            /// ID Locator Type
            /// </summary>
            Id,

            /// <summary>
            /// Accessibility Id Locator Type
            /// </summary>
            AccessibilityId,

            /// <summary>
            /// Name Locator Type
            /// </summary>
            Name,

            /// <summary>
            /// Xpath Locator Type
            /// </summary>
            XPath,

            /// <summary>
            /// CssSelector Locator Type
            /// </summary>
            CssSelector,

            /// <summary>
            /// ClassName Locator Type
            /// </summary>
            ClassName,

            /// <summary>
            /// LinkText Locator Type
            /// </summary>
            LinkText,

            /// <summary>
            /// PartialLinkText Locator Type
            /// </summary>
            PartialLinkText,

            /// <summary>
            /// TagName Locator Type
            /// </summary>
            TagName
        }
    }
}
﻿using NUnit.Framework;
using OpenQA.Selenium;
using OpenQA.Selenium.Appium;

namespace TestAutomation.Mobile.Core.MobileCore.Utilities
{
    /// <summary>
    /// Soft Assertion.
    /// </summary>
    public static class Verify
    {
        /// <summary>
        /// The wrapper for failing the test execution
        /// <example><code>
        /// How to use it: 
        /// Verify.Fail("Expected condition did not match");
        /// </code></example>
        /// </summary>
        /// <param name="message">Message to be logged</param>
        public static void Fail(string message)
        {
            try
            {
                Assert.Fail(message);
            }
            catch
            {
                ExtentReportHelper.LogTestAtVerify(message);
            }

        }

        /// <summary>
        /// The wrapper for IsTrue when case is true.
        /// The IsTrue will only be checked for the expected condition if case is true.
        /// If case is false, assertion will not happen.
        /// <example><code>
        /// How to use it: 
        /// Verify.IsTrueWhenCaseIsTrue(caseCondition, expectedCondition, driver, "When caseCondition was true, expectedCondition was false");
        /// </code></example>
        /// -- Test execution will continue even if this verify method fails.
        /// </summary>
        /// <param name="caseCondition">Case condition which determines whether or not IsTrue needs to be checked</param>
        /// <param name="expectedCondition">Expected condition which has to be true</param>
        /// <param name="driver">Active AppiumDriver instance</param>
        /// <param name="failureReason">Reason logged for failure</param>
        public static void IsTrueWhenCaseIsTrue(bool caseCondition, bool expectedCondition, AppiumDriver driver, string failureReason)
        {
            if (caseCondition)
            {
                try
                {
                    Assert.That(expectedCondition, Is.True, failureReason);
                }
                catch
                {
                    ExtentReportHelper.LogTestAtVerify(failureReason, driver);
                }
            }
        }

        /// <summary>
        /// The wrapper for IsFalse when case is false.
        /// The IsFalse will only be checked for the expected condition if case is false.
        /// If case is true, assertion will not happen.
        /// <example><code>
        /// How to use it: 
        /// Verify.IsFalseWhenCaseIsFalse(caseCondition, expectedCondition, driver, "When caseCondition was false, expectedCondition was true");
        /// </code></example>
        /// -- Test execution will continue even if this verify method fails.
        /// </summary>
        /// <param name="caseCondition">Case condition which determines whether or not IsFalse needs to be checked</param>
        /// <param name="expectedCondition">Expected condition which has to be false</param>
        /// <param name="driver">Active AppiumDriver instance</param>
        /// <param name="failureReason">Reason logged for failure</param>
        public static void IsFalseWhenCaseIsFalse(bool caseCondition, bool expectedCondition, AppiumDriver driver, string failureReason)
        {
            if (!caseCondition)
            {
                try
                {
                    Assert.That(expectedCondition, Is.False, failureReason);
                }
                catch
                {
                    ExtentReportHelper.LogTestAtVerify(failureReason, driver);
                }
            }
        }

        /// <summary>
        /// The wrapper for AreEqual when case is true.
        /// The AreEqual will only be checked between expected and actual objects if case is true.
        /// If case is false, assertion will not happen.
        /// <example><code>
        /// How to use it: 
        /// Verify.AreEqualWhenCaseIsTrue(caseCondition, 15, number, driver, "When caseCondition was true, number was not equal to 15");
        /// </code></example>
        /// -- Test execution will continue even if this verify method fails.
        /// </summary>
        /// <param name="caseCondtion">Case condition which determines whether or not AreEqual needs to be checked</param>
        /// <param name="expected">Expected object</param>
        /// <param name="actual">Actual Object</param>
        /// <param name="driver">Active AppiumDriver instance</param>
        /// <param name="failureReason">Reason logged for failure</param>
        public static void AreEqualWhenCaseIsTrue(bool caseCondtion, object expected, object actual, AppiumDriver driver, string failureReason)
        {
            if (caseCondtion)
            {
                try
                {
                    Assert.That(actual, Is.EqualTo(expected), failureReason);
                }
                catch
                {
                    ExtentReportHelper.LogTestAtVerify(failureReason, driver);
                }
            }
        }

        /// <summary>
        /// The wrapper for AreNotEqual when case is true.
        /// The AreNotEqual will only be checked between expected and actual objects if case is true.
        /// If case is false, assertion will not happen.
        /// <example><code>
        /// How to use it: 
        /// Verify.AreNotEqualWhenCaseIsTrue(caseCondition, 15, number, driver, "When caseCondition was true, number was equal to 15");
        /// </code></example>
        /// -- Test execution will continue even if this verify method fails.
        /// </summary>
        /// <param name="caseCondtion">Case condition which determines whether or not AreNotEqual needs to be checked</param>
        /// <param name="expected">Expected object</param>
        /// <param name="actual">Actual object</param>
        /// <param name="driver">Active AppiumDriver instance</param>
        /// <param name="failureReason">Reason logged for failure</param>
        public static void AreNotEqualWhenCaseIsTrue(bool caseCondtion, object expected, object actual, AppiumDriver driver, string failureReason)
        {
            if (caseCondtion)
            {
                try
                {
                    Assert.That(actual, Is.Not.EqualTo(expected), failureReason);
                }
                catch
                {
                    ExtentReportHelper.LogTestAtVerify(failureReason, driver);
                }
            }
        }

        /// <summary>
        /// The wrapper for AreEqual when case is false
        /// The AreEqual will only be checked between expected and actual objects if case is false.
        /// If case is true, assertion will not happen.
        /// <example><code>
        /// How to use it: 
        /// Verify.AreEqualWhenCaseIsFalse(caseCondition, 15, number, driver, "When caseCondition was false, number was not equal to 15");
        /// </code></example>
        /// -- Test execution will continue even if this verify method fails.
        /// </summary>
        /// <param name="caseCondtion">Case condition which determines whether or not AreNotEqual needs to be checked</param>
        /// <param name="expected">Expected object</param>
        /// <param name="actual">Actual object</param>
        /// <param name="driver">Active AppiumDriver instance</param>
        /// <param name="failureReason">Reason logged for failure</param>
        public static void AreEqualWhenCaseIsFalse(bool caseCondtion, object expected, object actual, AppiumDriver driver, string failureReason)
        {
            if (!caseCondtion)
            {
                try
                {
                    Assert.That(actual, Is.EqualTo(expected), failureReason);
                }
                catch
                {
                    ExtentReportHelper.LogTestAtVerify(failureReason, driver);
                }
            }
        }

        /// <summary>
        /// The wrapper for AreEqual.
        /// <example><code>
        /// How to use it: 
        /// Verify.AreEqual(15, number, driver);
        /// </code></example>
        /// -- Test execution will continue even if this verify method fails.
        /// </summary>
        /// <param name="expected">Expected object</param>
        /// <param name="actual">Actual object</param>
        /// <param name="driver">Active AppiumDriver instance</param>
        public static void AreEqual(object expected, object actual, AppiumDriver driver)
        {
            try
            {
                Assert.That(actual, Is.EqualTo(expected));
            }
            catch
            {
                ExtentReportHelper.LogTestAtVerify($"Expected {expected} but was {actual}", driver);
            }
        }

        /// <summary>
        /// The wrapper for AreNotEqual.
        /// <example><code>
        /// How to use it: 
        /// Verify.AreNotEqual(15, number, driver);
        /// </code></example>
        /// -- Test execution will continue even if this verify method fails.
        /// </summary>
        /// <param name="expected">Expected object</param>
        /// <param name="actual">Actual object</param>
        /// <param name="driver">Active AppiumDriver instance</param>
        public static void AreNotEqual(object expected, object actual, AppiumDriver driver)
        {
            try
            {
                Assert.That(actual, Is.Not.EqualTo(expected));
            }
            catch
            {
                ExtentReportHelper.LogTestAtVerify($"{expected} was found to be equal to {actual}", driver);
            }
        }

        /// <summary>
        /// The wrapper for IsTrue.
        /// <example><code>
        /// How to use it: 
        /// Verify.IsTrue(expectedCondition, driver, Expected condition was false);
        /// </code></example>
        /// -- Test execution will continue even if this verify method fails.
        /// </summary>
        /// <param name="expected">Expected condition which has to be true</param>
        /// <param name="driver">Active AppiumDriver instance</param>
        /// <param name="failureReason">Reason logged for failure</param>
        public static void IsTrue(bool expected, AppiumDriver driver, string failureReason)
        {
            try
            {
                Assert.That(expected, Is.True, failureReason);
            }
            catch
            {
                ExtentReportHelper.LogTestAtVerify(failureReason, driver);
            }
        }

        /// <summary>
        /// The wrapper for IsFalse.
        /// <example><code>
        /// How to use it: 
        /// Verify.IsFalse(expectedCondition, driver, Expected condition was true);
        /// </code></example>
        /// -- Test execution will continue even if this verify method fails.
        /// </summary>
        /// <param name="expected">Expected condition</param>
        /// <param name="driver">Active AppiumDriver instance</param>
        /// <param name="failureReason">Reason logged for failure</param>
        public static void IsFalse(bool expected, AppiumDriver driver, string failureReason)
        {
            try
            {
                Assert.That(expected, Is.False, failureReason);
            }
            catch
            {
                ExtentReportHelper.LogTestAtVerify(failureReason, driver);
            }
        }

        /// <summary>
        /// The assertion for validating string does contains the provided sub-string.
        /// <example><code>
        /// How to use it: 
        /// Verify.IsContains(fullName, firstName, driver);
        /// </code></example>
        /// -- Test execution will continue even if this verify method fails.
        /// </summary>
        /// <param name="parentString">String which should contain the expected string</param>
        /// <param name="stringToBeContained">Expected string to be contained in the parent string</param>
        /// <param name="driver">Active AppiumDriver instance</param>
        public static void IsContains(string parentString, string stringToBeContained, AppiumDriver driver)
        {
            try
            {
                Assert.That(parentString, Contains.Substring(stringToBeContained));
            }
            catch
            {
                ExtentReportHelper.LogTestAtVerify($"{parentString} does not contain {stringToBeContained}", driver);
            }
        }

        /// <summary>
        /// The assertion for validating string does not contain the provided sub-string.
        /// <example><code>
        /// How to use it: 
        /// Verify.IsNotContains(fullName, salutation, driver);
        /// </code></example>
        /// -- Test execution will continue even if this verify method fails.
        /// </summary>
        /// <param name="parentString">String which should not contain the expected string</param>
        /// <param name="stringNotToBeContained">Expected string not to be contained in the parent string</param>
        /// <param name="driver">Active AppiumDriver instance</param>
        public static void IsNotContains(string parentString, string stringNotToBeContained, AppiumDriver driver)
        {
            try
            {
                Assert.That(parentString, Does.Not.Contains(stringNotToBeContained));
            }
            catch
            {
                ExtentReportHelper.LogTestAtVerify($"{parentString} does contain {stringNotToBeContained}", driver);
            }
        }

        /// <summary>
        /// The assertion for validating expected string is present in list of string items.
        /// <example><code>
        /// How to use it: 
        /// Verify.ListContainsExpectedValue(nameList, userName, driver);
        /// </code></example>
        /// -- Test execution will continue even if this verify method fails.
        /// </summary>
        /// <param name="expectedString">Expected string to be present in the list</param>
        /// <param name="listOfItems">List of string items</param>
        /// <param name="driver">Active AppiumDriver instance</param>
        public static void ListContainsExpectedValue(string expectedString, List<string> listOfItems, AppiumDriver driver)
        {
            try
            {
                Assert.That(listOfItems, Contains.Item(expectedString));
            }
            catch
            {
                ExtentReportHelper.LogTestAtVerify("Expected string '" + expectedString + "' was not present in the list of string", driver);
            }
        }

        /// <summary>
        /// The assertion for validating expected string is not present in list of string items.
        /// <example><code>
        /// How to use it: 
        /// Verify.ListNotContainsExpectedValue(nameList, jobTitle, driver);
        /// </code></example>
        /// -- Test execution will continue even if this verify method fails.
        /// </summary>
        /// <param name="expectedString">Expected string to be not present in the list</param>
        /// <param name="listOfItems">List of string items</param>
        /// <param name="driver">Active AppiumDriver instance</param>
        public static void ListNotContainsExpectedValue(object expectedString, List<object> listOfItems, AppiumDriver driver)
        {
            try
            {
                Assert.That(listOfItems, Does.Not.Contains(expectedString));
            }
            catch
            {
                ExtentReportHelper.LogTestAtVerify("Expected string '" + expectedString + "' is present in the list of string", driver);
            }
        }

        /// <summary>
        /// The assertion for validating whether the string conatins all the string items in the list
        /// <example><code>
        /// How to use it: 
        /// Verify.IsStringContainsListOfItems(responseContent, ListOfUserIds, driver);
        /// </code></example>
        /// -- Test execution will continue even if this verify method fails.
        /// </summary>
        /// <param name="actualString">Actual string which should contain all the string items in the list</param>
        /// <param name="listOfItems">List of string items to be contained in the actual string</param>
        /// <param name="driver">Active AppiumDriver instance</param>
        public static void IsStringContainsListOfItems(string actualString, List<string> listOfItems, AppiumDriver driver)
        {
            foreach (string item in listOfItems)
            {
                IsContains(actualString, item, driver);
            }
        }

        /// <summary>
        /// The assertion for validating the two list values are equal.
        /// <example><code>
        /// How to use it: 
        /// Verify.ActualAndExpectedListItemsAreEqual(responseContent, ListOfUserIds, driver);
        /// </code></example>
        /// -- Test execution will continue even if this verify method fails.
        /// </summary>
        /// <param name="actualListOfItems">Actual list items</param>
        /// <param name="expectedListOfItems">Expected list items</param>
        /// <param name="driver">Active AppiumDriver instance</param>
        public static void ActualAndExpectedListItemsAreEqual(List<string> actualListOfItems, List<string> expectedListOfItems, AppiumDriver driver)
        {
            for (int i = 0; i < actualListOfItems.Count; i++)
            {
                AreEqual(actualListOfItems[i], expectedListOfItems[i], driver);
            }
        }

        /// <summary>
        /// Verify group of assertions.
        /// <example><code>
        /// How to use it: 
        /// Verify.That(
        ///    () => Verify.AreEqual(true, true, _broserDriver),
        ///    () => Verify.AreEqual("Your e-mail's been sent!", successMessage, _broserDriver));
        /// </code></example>
        /// </summary>
        /// <param name="myAsserts">Group assertions.</param>
        public static void That(params Action[] myAsserts)
        {
            foreach(Action assert in myAsserts)
            {
                assert.Invoke();
            }
        }
    }
}
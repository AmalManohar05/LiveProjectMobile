﻿using NUnit.Framework;

namespace TestAutomation.Mobile.Core.MobileCore.Utilities
{
    /// <summary>
    /// Test Configuration methods
    /// </summary>
    public static class TestConfig
    {
        /// <summary>
        /// To ignore the test from further execution
        /// <example><code>
        /// How to use it: 
        /// TestConfig.TestIgnore(condition, Test can be skiped when ABCD switch is true);
        /// TestConfig.TestIgnore(!condition, Test can be skiped when ABCD switch is false);
        /// </code></example>
        /// </summary>
        /// <param name="condition">condition</param>
        /// <param name="testIgnoreReason">failureReason</param>
        public static void TestIgnore(bool condition, string testIgnoreReason)
        {
            if (condition)
            {
                Assert.Ignore(testIgnoreReason);
            }
        }

        /// <summary>
        /// To continue the test for further execution
        /// <example><code>
        /// How to use it: 
        /// TestConfig.TestContinue(condition, Test can be continued when ABCD switch is true);
        /// TestConfig.TestContinue(!condition, Test can be continued when ABCD switch is false);
        /// </code></example>
        /// </summary>
        /// <param name="condition">condition</param>
        /// <param name="testContinueReason">Reason</param>
        public static void TestContinue(bool condition, string testContinueReason)
        {
            if (!condition)
            {
                Assert.Ignore(testContinueReason);
            }
        }

        /// <summary>
        /// To Fai the test from further execution
        /// <example><code>
        /// How to use it: 
        /// TestConfig.TestFail(condition, Test can be failed when ABCD switch is true);
        /// TestConfig.TestFail(!condition, Test can be failed when ABCD switch is false);
        /// </code></example>
        /// </summary>
        /// <param name="condition">condition</param>
        /// <param name="testFailReason">Reason</param>
        public static void TestFail(bool condition, string testFailReason)
        {
            if (condition)
            {
                Assert.Fail(testFailReason);
            }
        }
    }
}
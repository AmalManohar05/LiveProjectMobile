﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Sockets;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using System.Reflection;

namespace TestAutomation.Mobile.Core.MobileCore.Utilities
{
    public class FileUtils
    {
        /// <summary>
        /// Get project directory
        /// <example><code>
        /// #How to use it: 
        /// FilesHelpers.GetProjectDirectory();
        /// </code></example>
        /// </summary>
        /// <returns>Will return the project directory path</returns>
        public static string GetProjectDirectory() => Directory.GetParent(Assembly.GetExecutingAssembly().Location)!.Parent!.Parent!.Parent!.FullName;
    }
}
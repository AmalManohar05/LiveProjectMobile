﻿using AventStack.ExtentReports;
using AventStack.ExtentReports.Model;
using AventStack.ExtentReports.Reporter;
using AventStack.ExtentReports.Reporter.Config;
using NUnit.Framework;
using NUnit.Framework.Interfaces;
using OpenQA.Selenium;
using OpenQA.Selenium.Appium;
using System.Text;
using TestAutomation.Mobile.Core.MobileCore.Core;
using TestAutomation.Mobile.Core.MobileCore.Extensions;

namespace TestAutomation.Mobile.Core.MobileCore.Utilities
{
    /// <summary>
    /// The Extent Reports support class .
    /// </summary>
    public static class ExtentReportHelper
    {
        /// <summary>
        /// Extent report object
        /// </summary>
        private static ExtentReports? _extent;

        /// <summary>
        /// Thread static extent test object
        /// </summary>
        [ThreadStatic]
        private static ExtentTest? _test;

        /// <summary>
        /// Last Stack trace field property
        /// </summary>
        private static List<string> _lastStackTrace;

        /// <summary>
        /// To invoke the last stack trace property field
        /// </summary>
        static ExtentReportHelper()
        {
            _lastStackTrace = new();
        }


        /// <summary>
        /// To initalize the extent report
        /// </summary>
        /// <returns>Extent object</returns>
        public static ExtentReports InitializeExtentReports(bool isJsonFileNeeded = false)
        {
            _extent = new ExtentReports();

            string dateTime = DateTime.Now.ToString("yyyy_MM_dd_HH_mm_ss");
            string reportName = TestContext.Parameters["reportName"]!;
            string basePath = Directory.GetParent(Environment.CurrentDirectory)!.Parent!.Parent!.FullName + "\\TestAutomationReports\\";

            string htmlPath = $"{basePath}{reportName}_{dateTime}.html";
            var htmlReporter = new ExtentSparkReporter(htmlPath);

            htmlReporter.Config.Theme = Theme.Dark;
            _extent.AddSystemInfo("Author", TestContext.Parameters["authorForReport"]);
            _extent.AddSystemInfo("OS", Environment.OSVersion.ToString());

            if (isJsonFileNeeded)
            {
                string jsonPath = $"{basePath}{reportName}_{dateTime}.json";
                var json = new ExtentJsonFormatter(jsonPath);
                _extent.AttachReporter(json, htmlReporter);
            }
            else
            {
                _extent.AttachReporter(htmlReporter);
            }

            return _extent;
        }

        /// <summary>
        /// To genrate the final report via extent flush
        /// </summary>
        public static void GenerateReport()
        {
            _extent?.Flush();
        }

        /// <summary>
        /// To create a test
        /// </summary>
        public static void CreateTest()
        {
            string testDescription = TestContext.CurrentContext.Test.Properties.ContainsKey("Description") ? TestContext.CurrentContext.Test.Properties.Get("Description")!.ToString()! : "";
            if (TestContext.CurrentContext.Test.Properties.ContainsKey("Test Scenario"))
            {
                StringBuilder scenarios = new StringBuilder();
                scenarios.Append("\n || Scenarios Covered : \n");
                foreach (string scenario in TestContext.CurrentContext.Test.Properties["Test Scenario"])
                {
                    scenarios.Append($" {scenario},");
                }
                scenarios.Length--;
                testDescription += scenarios.ToString();
            }
            _test = _extent?.CreateTest(TestContext.CurrentContext.Test.Name, testDescription);
            if (TestContext.CurrentContext.Test.Properties.ContainsKey("Category"))
            {
                foreach (var category in TestContext.CurrentContext.Test.Properties["Category"])
                {
                    _test?.AssignCategory(category.ToString());
                }
            }
        }

        /// <summary>
        /// Will log all the status outcome of Test result
        /// </summary>
        /// <param name="driver"></param>
        public static void LogTestEnd(AppiumDriver driver = null!)
        {
            TestStatus outcome = TestContext.CurrentContext.Result.Outcome.Status;
            switch (outcome)
            {
                case TestStatus.Failed:
                    if (_lastStackTrace.Any(x => x == TestContext.CurrentContext.Result.StackTrace) || TestContext.CurrentContext.Result.StackTrace == null)
                        break;
                    _test?.Fail("Test Status: " + TestContext.CurrentContext.Result.Outcome.Status);
                    if (driver != null)
                    {
                        _test?.Fail(ScreenShotsCaptureAndReturnModel(driver));
                        var screenshotPath = driver.CaptureScreenshots(Directory.GetParent(Environment.CurrentDirectory)!.Parent!.Parent!.FullName + "\\TestAutomationReports\\FailedScreenshots_" + DateTime.Now.ToString("yyyy_MM_dd") + "\\");
                        TestContext.AddTestAttachment(screenshotPath);
                    }
                    if (TestContext.CurrentContext.Result.Message.StartsWith("Multiple failures or warnings in test:"))
                        _test?.Fail("Message: " + TestContext.CurrentContext.Result.Assertions.Last().Message);
                    else
                        _test?.Fail("Message: " + TestContext.CurrentContext.Result.Message.Split("Multiple failures or warnings in test:")[0]);
                    _test?.Fail("Stack Trace: " + TestContext.CurrentContext.Result.StackTrace);
                    break;
                case TestStatus.Passed:
                    _test?.Pass("This test passed, hooray!");
                    break;
                case TestStatus.Skipped:
                    _test?.Skip("Test Status: " + TestContext.CurrentContext.Result.Outcome.Status);
                    _test?.Info("Test skipped - " + TestContext.CurrentContext.Result.Message);
                    break;
                default:
                    _test?.Warning("Unexpected test status: " + TestContext.CurrentContext.Result.Outcome.Status);
                    break;
            }
        }

        /// <summary>
        /// To log all the custom assertion of verify
        /// </summary>
        /// <param name="message"></param>
        /// <param name="driver"></param>
        public static void LogTestAtVerify(string message, AppiumDriver driver = null!)
        {
            if (_test == null) return;
            TestStatus outcome = TestContext.CurrentContext.Result.Outcome.Status;
            switch (outcome)
            {
                case TestStatus.Failed:
                    _test.Fail("Test Status: " + "Test Failed at Verify");
                    if (driver != null)
                    {
                        _test.Fail(ScreenShotsCaptureAndReturnModel(driver));
                        var screenshotPath = driver.CaptureScreenshots(Directory.GetParent(Environment.CurrentDirectory)!.Parent!.Parent!.FullName + "\\TestAutomationReports\\FailedScreenshots_" + DateTime.Now.ToString("yyyy_MM_dd") + "\\");
                        TestContext.AddTestAttachment(screenshotPath);
                    }
                    _test.Fail("Message: " + message);
                    _test.Fail("Stack Trace: " + TestContext.CurrentContext.Result.Assertions.Last().StackTrace);
                    _lastStackTrace.Add(TestContext.CurrentContext.Result.Assertions.Last().StackTrace!);
                    break;
                case TestStatus.Passed:
                    _test.Pass("This test passed, hooray!");
                    break;
                case TestStatus.Skipped:
                    _test.Skip("Test Status: " + TestContext.CurrentContext.Result.Outcome.Status);
                    _test.Info("Test skipped - " + TestContext.CurrentContext.Result.Message);
                    break;
                default:
                    _test.Warning("Unexpected test status: " + TestContext.CurrentContext.Result.Outcome.Status);
                    break;
            }
        }

        /// <summary>
        /// To log the information to the extent report
        /// </summary>
        /// <param name="logMessage">The message to be added in the log</param>
        public static void Log(string logMessage, AppiumDriver driver = null!)
        {
            string isLoggerEnabledStr = TestContext.Parameters["isExtentLoggerEnabled"]!;
            bool isLoggerEnabled;

            if (bool.TryParse(isLoggerEnabledStr, out isLoggerEnabled) && isLoggerEnabled && _test != null)
            {
                _test.Info(logMessage);
                if (driver != null)
                {
                    _test.Info(ScreenShotsCaptureAndReturnModelForLogger(driver));
                }
            }
        }

        /// <summary>
        /// The ScreenShot Capture.
        /// </summary>
        /// <returns>Media builder.</returns>
        /// <param name="driver">driver</param>
        public static Media ScreenShotsCaptureAndReturnModel(AppiumDriver driver)
        {
            var screenshot = ((ITakesScreenshot)driver).GetScreenshot().AsBase64EncodedString;
            return MediaEntityBuilder.CreateScreenCaptureFromBase64String(screenshot, TestContext.CurrentContext.Test.Name + "_FailedScreenshot").Build();
        }

        /// <summary>
        /// The ScreenShot Capture.
        /// </summary>
        /// <returns>Media builder.</returns>
        /// <param name="driver">driver</param>
        public static Media ScreenShotsCaptureAndReturnModelForLogger(AppiumDriver driver)
        {
            var screenshot = ((ITakesScreenshot)driver).GetScreenshot().AsBase64EncodedString;
            return MediaEntityBuilder.CreateScreenCaptureFromBase64String(screenshot, "Screenshot").Build();
        }
    }

    [AttributeUsage(AttributeTargets.Class, AllowMultiple = false)]
    public class ExtentReportAttribute : NUnitAttribute, ITestAction
    {

        public ExtentReportAttribute(bool isJsonFileNeeded = false)
        {
            ExtentReportHelper.InitializeExtentReports(isJsonFileNeeded);
        }

        public ActionTargets Targets => ActionTargets.Suite | ActionTargets.Test;

        /// <summary>
        /// Run before test
        /// </summary>
        /// <param name="test">ITest instance</param>
        public void BeforeTest(ITest test)
        {
            if (!test.IsSuite)
            {
                ExtentReportHelper.CreateTest();
            }
        }

        /// <summary>
        /// Run after test
        /// </summary>
        /// <param name="test">ITest instance</param>
        public void AfterTest(ITest test)
        {
            var testFixture = test.Fixture as TestBase;
            if (test.IsSuite)
            {
                ExtentReportHelper.GenerateReport();
            }
            else
            {
                if (testFixture != null)
                    ExtentReportHelper.LogTestEnd(testFixture!._appDriver!);
                else
                    ExtentReportHelper.LogTestEnd();
            }
        }
    }
}
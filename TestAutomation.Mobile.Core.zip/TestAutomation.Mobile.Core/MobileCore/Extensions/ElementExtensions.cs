﻿using OpenQA.Selenium.Support.UI;
using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using OpenQA.Selenium.Appium;

namespace TestAutomation.Mobile.Core.MobileCore.Extensions
{
    public static class ElementExtensions
    {
        /// <summary>
        /// Gets the selected value in a dropdown.
        /// <example><code>
        /// #How to use it: 
        /// element.GetSelectedDropDownValue();
        /// </code></example>
        /// </summary>
        /// <param name="element">The appium element calling this method</param>
        /// <returns>Selected value</returns>
        public static string GetSelectedDropDownValue(this AppiumElement element)
            => new SelectElement(element).SelectedOption.Text;

        /// <summary>
        /// Gets the selected options from a dropdown.
        /// <example><code>
        /// #How to use it: 
        /// element.GetAllSelectedOptions();
        /// </code></example>
        /// </summary>
        /// <param name="element">The appium element calling this method</param>
        /// <returns>List of all selected drop down elements.</returns>
        public static IList<AppiumElement> GetAllSelectedOptions(this AppiumElement element)
            => (IList<AppiumElement>)new SelectElement(element).AllSelectedOptions;

        /// <summary>
        /// Select an option from dropdown by value.
        /// <example><code>
        /// #How to use it: 
        /// element.SelectDropDownListByValue("itemValue");
        /// </code></example>
        /// </summary>
        /// <param name="element">The appium element calling this method</param>
        /// <param name="value">Value to be selected</param>
        public static void SelectDropDownListByValue(this AppiumElement element, string value)
            => new SelectElement(element).SelectByValue(value);

        /// <summary>
        /// Gets all list of values from a dropdown.
        /// <example><code>
        /// #How to use it: 
        /// element.GetAllDropdownOptions();
        /// </code></example>
        /// </summary>
        /// <param name="element">The appium element calling this method</param>
        /// <returns>List of all drop down options</returns>
        public static IList<AppiumElement> GetAllDropdownOptions(this AppiumElement element)
            => (IList<AppiumElement>)new SelectElement(element).Options;

        /// <summary>
        /// Gets text from an element.
        /// <example><code>
        /// #How to use it: 
        /// element.GetElementText();
        /// </code></example>
        /// </summary>
        /// <param name="element">The appium element calling this method</param>
        /// <returns>Element Text.</returns>
        public static string GetElementText(this AppiumElement element)
        {
            return element.Text;
        }

        /// <summary>
        /// Get the required attribute value of the element
        /// <example><code>
        /// #How to use it: 
        /// element.GetElementAttributeValue("placeHolder");
        /// </code></example>
        /// </summary>
        /// <param name="element">The appium element calling this method</param>
        /// <param name="attributeName">Required attribute name</param>
        /// <returns>The attribute value</returns>
        public static string GetElementAttributeValue(this AppiumElement element, string attributeName)
            => element.GetAttribute(attributeName);

        /// <summary>
        /// Select an option from dropdown based on text.
        /// <example><code>
        /// #How to use it: 
        /// element.SelectDropDownListByText("itemName");
        /// </code></example>
        /// </summary>
        /// <param name="element">The appium element calling this method</param>
        /// <param name="value">Text value to be selected</param>
        public static void SelectDropDownListByText(this AppiumElement element, string value)
            => new SelectElement(element).SelectByText(value);

        /// <summary>
        /// Check the element is present or not.
        /// <example><code>
        /// #How to use it: 
        /// element.IsElementPresent();
        /// </code></example>
        /// </summary>
        /// <param name="element">The appium element calling this method</param>
        /// <returns>Whether the element is present in Ui or not (true/false).</returns>
        public static bool IsElementDisplayed(AppiumElement element)
            => element.Displayed;

        /// <summary>
        /// Check if the attribute is not present
        /// <example><code>
        /// #How to use it: 
        /// element.IsAttributeNotPresent("href");
        /// </code></example>
        /// </summary>
        /// <param name="element">The appium element calling this method</param>
        /// <param name="attributeType">Attribute name.</param>
        /// <returns>Whether the element does not contains the given attribute (true/false).</returns>
        public static bool IsAttributeNotPresent(this AppiumElement element, string attributeType)
        {
            bool result = false;
            try
            {
                string value = element.GetAttribute(attributeType);
                if (value == string.Empty || value == null)
                {
                    result = true;
                }
            }
            catch (Exception)
            {
                //TODO: Any actions in catch? Log? Throw ?
            }

            return result;
        }

        /// <summary>
        /// Clear all text content
        /// <example><code>
        /// #How to use it: 
        /// element.ClearAll();
        /// </code></example>
        /// </summary>
        /// <param name="element">The appium element calling this method</param>
        public static void ClearAll(this AppiumElement element)
        {
            element.SendKeys(Keys.Control + "a");
            element.SendKeys("\b");
        }

        /// <summary>
        /// Clear text using backspace.
        /// <example><code>
        /// #How to use it: 
        /// element.ClearTextUsingBackSpace();
        /// </code></example>
        /// </summary>
        /// <param name="element">The appium element calling this method</param>
        public static void ClearTextUsingBackSpace(this AppiumElement element)
        {
            int numberOfCharacters = element.GetAttribute("value").Length;
            for (int count = 1; count <= numberOfCharacters; count++)
            {
                element.SendKeys(Keys.Backspace);
            }
        }

        /// <summary>
        /// Clear text using backspace.
        /// <example><code>
        /// #How to use it: 
        /// element.ClearTextUsingBackSpace(7);
        /// </code></example>
        /// </summary>
        /// <param name="element">The appium element calling this method</param>
        /// <param name="numberOfCharacters">Number of times backspace is used.</param>
        public static void ClearTextUsingBackSpace(this AppiumElement element, int numberOfCharacters)
        {
            for (int count = 1; count <= numberOfCharacters; count++)
            {
                element.SendKeys(Keys.Backspace);
            }
        }
    }
}
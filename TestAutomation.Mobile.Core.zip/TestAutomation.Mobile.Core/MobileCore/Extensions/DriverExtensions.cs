﻿using NUnit.Framework;
using OpenQA.Selenium;
using OpenQA.Selenium.Appium;
using OpenQA.Selenium.Interactions;
using OpenQA.Selenium.Support.UI;
using SeleniumExtras.WaitHelpers;
using System.Reflection;
using TestAutomation.Mobile.Core.MobileCore.Utilities;

namespace TestAutomation.Mobile.Core.MobileCore.Extensions
{
    /// <summary>
    /// The Appium driver extension.
    /// </summary>
    public static class DriverExtensions
    {
        /// <summary>
        /// Wait for text to be present in element value
        /// </summary>
        /// <param name="driver">The current appium driver instance</param>
        /// <param name="element">The element whose value attribute is being checked</param>
        /// <param name="text">The text to be present in the value attribute</param>
        /// <param name="timeout">The timeout for the text to be present</param>
        public static void WaitForTextToBePresentInElementValue(this AppiumDriver driver, AppiumElement element, string text, int timeout = 60)
        {
            WebDriverWait wait = new(driver, TimeSpan.FromSeconds(timeout));
            wait.Until(ExpectedConditions.TextToBePresentInElementValue(element, text));
        }

        /// <summary>
        /// Wait for text to be present in element value
        /// </summary>
        /// <param name="driver">The current appium driver instance</param>
        /// <param name="element">The lazy for the element whose value attribute is being checked</param>
        /// <param name="text">The text to be present in the value attribute</param>
        /// <param name="timeout">The timeout for the text to be present</param>
        public static void WaitForTextToBePresentInElementValue(this AppiumDriver driver, Lazy<AppiumElement> element, string text, int timeout = 60)
        {
            WebDriverWait wait = new(driver, TimeSpan.FromSeconds(timeout));
            wait.Until(ExpectedConditions.TextToBePresentInElementValue(element.Value, text));
        }

        /// <summary>
        /// Wait for staleness of an element
        /// </summary>
        /// <param name="driver">The current appium driver instance</param>
        /// <param name="element">The element whose staleness is being checked</param>
        /// <param name="timeout">The timeout for staleness</param>
        public static void WaitForStalenessOf(this AppiumDriver driver, AppiumElement element, int timeout = 60)
        {
            WebDriverWait wait = new(driver, TimeSpan.FromSeconds(timeout));
            wait.Until(ExpectedConditions.StalenessOf(element));
        }

        /// <summary>
        ///  Wait for staleness of an element
        /// </summary>
        /// <param name="driver">The current appium driver instance</param>
        /// <param name="element">The element whose staleness is being checked</param>
        /// <param name="timeout">The timeout for staleness</param>
        public static void WaitForStalenessOf(this AppiumDriver driver, Lazy<AppiumElement> element, int timeout = 60)
        {
            WebDriverWait wait = new(driver, TimeSpan.FromSeconds(timeout));
            wait.Until(ExpectedConditions.StalenessOf(element.Value));
        }

        /// <summary>
        /// Get the page source of the last loaded page
        /// </summary>
        /// <param name="driver">The current appium driver instance</param>
        /// <returns>Page source details</returns>
        public static string GetPageSource(this AppiumDriver driver)
        {
            return driver.PageSource;
        }

        /// <summary>
        /// Wait for text to be present in element value
        /// </summary>
        /// <param name="driver">The current appium driver instance</param>
        /// <param name="element">The string locator value of the element whose value attribute is being checked</param>
        /// <param name="text">The text to be present in the value attribute</param>
        /// <param name="locatorType">The locator type enum value for locating the element</param>
        /// <param name="timeout">The timeout for the element value</param>
        /// <exception cref="ArgumentOutOfRangeException">No such locator type is specified in the enum</exception>
        public static void WaitForTextToBePresentInElementValue(this AppiumDriver driver, string element, string text, Enum locatorType, int timeout = 60)
        {
            WebDriverWait wait = new(driver, TimeSpan.FromSeconds(timeout));
            By locator = locatorType switch
            {
                Locator.LocatorType.XPath => By.XPath(element),
                Locator.LocatorType.Id => By.Id(element),
                Locator.LocatorType.AccessibilityId => MobileBy.AccessibilityId(element),
                Locator.LocatorType.Name => By.Name(element),
                Locator.LocatorType.ClassName => By.ClassName(element),
                Locator.LocatorType.CssSelector => By.CssSelector(element),
                Locator.LocatorType.LinkText => By.LinkText(element),
                Locator.LocatorType.PartialLinkText => By.PartialLinkText(element),
                Locator.LocatorType.TagName => By.TagName(element),
                _ => throw new ArgumentOutOfRangeException($"No such locator type: {locatorType}")
            };
            wait.Until(ExpectedConditions.TextToBePresentInElementValue(locator, text));
        }

        /// <summary>
        /// Wait for text to be present in element value
        /// </summary>
        /// <param name="driver">The current appium driver instance</param>
        /// <param name="element">The lazy string locator value of the element whose value attribute is being checked</param>
        /// <param name="text">The text to be present in the value attribute</param>
        /// <param name="locatorType">The locator type enum value for locating the element</param>
        /// <param name="timeout">The timeout for the element value</param>
        /// <exception cref="ArgumentOutOfRangeException">No such locator type is specified in the enum</exception>
        public static void WaitForTextToBePresentInElementValue(this AppiumDriver driver, Lazy<string> element, string text, Enum locatorType, int timeout = 60)
        {
            WebDriverWait wait = new(driver, TimeSpan.FromSeconds(timeout));
            By locator = locatorType switch
            {
                Locator.LocatorType.XPath => By.XPath(element.Value),
                Locator.LocatorType.Id => By.Id(element.Value),
                Locator.LocatorType.AccessibilityId => MobileBy.AccessibilityId(element.Value),
                Locator.LocatorType.Name => By.Name(element.Value),
                Locator.LocatorType.ClassName => By.ClassName(element.Value),
                Locator.LocatorType.CssSelector => By.CssSelector(element.Value),
                Locator.LocatorType.LinkText => By.LinkText(element.Value),
                Locator.LocatorType.PartialLinkText => By.PartialLinkText(element.Value),
                Locator.LocatorType.TagName => By.TagName(element.Value),
                _ => throw new ArgumentOutOfRangeException($"No such locator type: {locatorType}")
            };
            wait.Until(ExpectedConditions.TextToBePresentInElementValue(locator, text));
        }

        /// <summary>
        /// Wait for frame to be available and switch to it
        /// </summary>
        /// <param name="driver">The current appium driver instance</param>
        /// <param name="element">The string element whose availability is being checked</param>
        /// <param name="locatorType">The locator type enum value for locating the element</param>
        /// <param name="timeout">The timeout for the frame to be available</param>
        /// <exception cref="ArgumentOutOfRangeException">No such locator type is specified in the enum</exception>
        public static void WaitForFrameToBeAvailableAndSwitchToIt(this AppiumDriver driver, string element, Enum locatorType, int timeout = 60)
        {
            WebDriverWait wait = new(driver, TimeSpan.FromSeconds(timeout));
            By locator = locatorType switch
            {
                Locator.LocatorType.XPath => By.XPath(element),
                Locator.LocatorType.Id => By.Id(element),
                Locator.LocatorType.AccessibilityId => MobileBy.AccessibilityId(element),
                Locator.LocatorType.Name => By.Name(element),
                Locator.LocatorType.ClassName => By.ClassName(element),
                Locator.LocatorType.CssSelector => By.CssSelector(element),
                Locator.LocatorType.LinkText => By.LinkText(element),
                Locator.LocatorType.PartialLinkText => By.PartialLinkText(element),
                Locator.LocatorType.TagName => By.TagName(element),
                _ => throw new ArgumentOutOfRangeException($"No such locator type: {locatorType}")
            };
            wait.Until(ExpectedConditions.FrameToBeAvailableAndSwitchToIt(locator));
        }

        /// <summary>
        /// Wait for element exists
        /// </summary>
        /// <param name="driver">The current appium driver instance</param>
        /// <param name="element">The string locator value of the element whose existence is being checked</param>
        /// <param name="locatorType">The locator type enum value for locating the element</param>
        /// <param name="timeout">The timeout for the element to exist</param>
        /// <exception cref="ArgumentOutOfRangeException">No such locator type is specified in the enum</exception>
        public static void WaitForElementExists(this AppiumDriver driver, string element, Enum locatorType, int timeout = 60)
        {
            WebDriverWait wait = new(driver, TimeSpan.FromSeconds(timeout));
            By locator = locatorType switch
            {
                Locator.LocatorType.XPath => By.XPath(element),
                Locator.LocatorType.Id => By.Id(element),
                Locator.LocatorType.AccessibilityId => MobileBy.AccessibilityId(element),
                Locator.LocatorType.Name => By.Name(element),
                Locator.LocatorType.ClassName => By.ClassName(element),
                Locator.LocatorType.CssSelector => By.CssSelector(element),
                Locator.LocatorType.LinkText => By.LinkText(element),
                Locator.LocatorType.PartialLinkText => By.PartialLinkText(element),
                Locator.LocatorType.TagName => By.TagName(element),
                _ => throw new ArgumentOutOfRangeException($"No such locator type: {locatorType}")
            };
            wait.Until(ExpectedConditions.ElementExists(locator));
        }

        /// <summary>
        /// Wait for element exists
        /// </summary>
        /// <param name="driver">The current appium driver instance</param>
        /// <param name="element">The lazy string locator value of the element whose existence is being checked</param>
        /// <param name="locatorType">The locator type enum value for locating the element</param>
        /// <param name="timeout">The timeout for the element to exist</param>
        /// <exception cref="ArgumentOutOfRangeException">No such locator type is specified in the enum</exception>
        public static void WaitForElementExists(this AppiumDriver driver, Lazy<string> element, Enum locatorType, int timeout = 60)
        {
            WebDriverWait wait = new(driver, TimeSpan.FromSeconds(timeout));
            By locator = locatorType switch
            {
                Locator.LocatorType.XPath => By.XPath(element.Value),
                Locator.LocatorType.Id => By.Id(element.Value),
                Locator.LocatorType.AccessibilityId => MobileBy.AccessibilityId(element.Value),
                Locator.LocatorType.Name => By.Name(element.Value),
                Locator.LocatorType.ClassName => By.ClassName(element.Value),
                Locator.LocatorType.CssSelector => By.CssSelector(element.Value),
                Locator.LocatorType.LinkText => By.LinkText(element.Value),
                Locator.LocatorType.PartialLinkText => By.PartialLinkText(element.Value),
                Locator.LocatorType.TagName => By.TagName(element.Value),
                _ => throw new ArgumentOutOfRangeException($"No such locator type: {locatorType}")
            };
            wait.Until(ExpectedConditions.ElementExists(locator));
        }

        /// <summary>
        /// Wait for the element to be clickable
        /// </summary>
        /// <param name="driver">The current appium driver instance</param>
        /// <param name="element">The string locator value of the element which should be clickable</param>
        /// <param name="locatorType">The locator type enum value for locating the element</param>
        /// <param name="timeout">The timeout for the element to be clickable</param>
        /// <exception cref="ArgumentOutOfRangeException">No such locator type is specified in the enum</exception>
        public static void WaitForElementClickable(this AppiumDriver driver, string element, Enum locatorType, int timeout = 60)
        {
            WebDriverWait wait = new(driver, TimeSpan.FromSeconds(timeout));
            By locator = locatorType switch
            {
                Locator.LocatorType.XPath => By.XPath(element),
                Locator.LocatorType.Id => By.Id(element),
                Locator.LocatorType.AccessibilityId => MobileBy.AccessibilityId(element),
                Locator.LocatorType.Name => By.Name(element),
                Locator.LocatorType.ClassName => By.ClassName(element),
                Locator.LocatorType.CssSelector => By.CssSelector(element),
                Locator.LocatorType.LinkText => By.LinkText(element),
                Locator.LocatorType.PartialLinkText => By.PartialLinkText(element),
                Locator.LocatorType.TagName => By.TagName(element),
                _ => throw new ArgumentOutOfRangeException($"No such locator type: {locatorType}")
            };
            wait.Until(ExpectedConditions.ElementToBeClickable(locator));
        }

        /// <summary>
        /// Wait for the element to be clickable
        /// </summary>
        /// <param name="driver">The current appium driver instance</param>
        /// <param name="element">The lazy string locator value of the element which should be clickable</param>
        /// <param name="locatorType">The locator type enum value for locating the element</param>
        /// <param name="timeout">The timeout for the element to be clickable</param>
        /// <exception cref="ArgumentOutOfRangeException">No such locator type is specified in the enum</exception>
        public static void WaitForElementClickable(this AppiumDriver driver, Lazy<string> element, Enum locatorType, int timeout = 60)
        {
            WebDriverWait wait = new(driver, TimeSpan.FromSeconds(timeout));
            By locator = locatorType switch
            {
                Locator.LocatorType.XPath => By.XPath(element.Value),
                Locator.LocatorType.Id => By.Id(element.Value),
                Locator.LocatorType.AccessibilityId => MobileBy.AccessibilityId(element.Value),
                Locator.LocatorType.Name => By.Name(element.Value),
                Locator.LocatorType.ClassName => By.ClassName(element.Value),
                Locator.LocatorType.CssSelector => By.CssSelector(element.Value),
                Locator.LocatorType.LinkText => By.LinkText(element.Value),
                Locator.LocatorType.PartialLinkText => By.PartialLinkText(element.Value),
                Locator.LocatorType.TagName => By.TagName(element.Value),
                _ => throw new ArgumentOutOfRangeException($"No such locator type: {locatorType}")
            };
            wait.Until(ExpectedConditions.ElementToBeClickable(locator));
        }

        /// <summary>
        /// Wait for the element to be visible
        /// </summary>
        /// <param name="driver">The current appium driver instance</param>
        /// <param name="element">The string locator value of the element whose visibility is being checked</param>
        /// <param name="locatorType">The locator type enum value for locating the element</param>
        /// <param name="timeout">The timeout for the element to be visible</param>
        /// <exception cref="ArgumentOutOfRangeException">No such locator type is specified in the enum</exception>
        public static void WaitForElementIsVisible(this AppiumDriver driver, string element, Enum locatorType, int timeout = 60)
        {
            WebDriverWait wait = new(driver, TimeSpan.FromSeconds(timeout));
            By locator = locatorType switch
            {
                Locator.LocatorType.XPath => By.XPath(element),
                Locator.LocatorType.Id => By.Id(element),
                Locator.LocatorType.AccessibilityId => MobileBy.AccessibilityId(element),
                Locator.LocatorType.Name => By.Name(element),
                Locator.LocatorType.ClassName => By.ClassName(element),
                Locator.LocatorType.CssSelector => By.CssSelector(element),
                Locator.LocatorType.LinkText => By.LinkText(element),
                Locator.LocatorType.PartialLinkText => By.PartialLinkText(element),
                Locator.LocatorType.TagName => By.TagName(element),
                _ => throw new ArgumentOutOfRangeException($"No such locator type: {locatorType}")
            };
            wait.Until(ExpectedConditions.ElementIsVisible(locator));
        }

        /// <summary>
        /// Wait for the element to be visible
        /// </summary>
        /// <param name="driver">The current appium driver instance</param>
        /// <param name="element">The lazy string locator value of the element whose visibility is being checked</param>
        /// <param name="locatorType">The locator type enum value for locating the element</param>
        /// <param name="timeout">The timeout for the element to be visible</param>
        /// <exception cref="ArgumentOutOfRangeException">No such locator type is specified in the enum</exception>
        public static void WaitForElementIsVisible(this AppiumDriver driver, Lazy<string> element, Enum locatorType, int timeout = 60)
        {
            WebDriverWait wait = new(driver, TimeSpan.FromSeconds(timeout));
            By locator = locatorType switch
            {
                Locator.LocatorType.XPath => By.XPath(element.Value),
                Locator.LocatorType.Id => By.Id(element.Value),
                Locator.LocatorType.AccessibilityId => MobileBy.AccessibilityId(element.Value),
                Locator.LocatorType.Name => By.Name(element.Value),
                Locator.LocatorType.ClassName => By.ClassName(element.Value),
                Locator.LocatorType.CssSelector => By.CssSelector(element.Value),
                Locator.LocatorType.LinkText => By.LinkText(element.Value),
                Locator.LocatorType.PartialLinkText => By.PartialLinkText(element.Value),
                Locator.LocatorType.TagName => By.TagName(element.Value),
                _ => throw new ArgumentOutOfRangeException($"No such locator type: {locatorType}")
            };
            wait.Until(ExpectedConditions.ElementIsVisible(locator));
        }

        /// <summary>
        /// Wait for element to be invisible
        /// </summary>
        /// <param name="driver">The current appium driver instance</param>
        /// <param name="element">The string locator value of the element whose invisibility is being checked</param>
        /// <param name="locatorType">The locator type enum value for locating the element</param>
        /// <param name="timeout">The timeout for the element to be invisible</param>
        /// <exception cref="ArgumentOutOfRangeException">No such locator type is specified in the enum</exception>
        public static void WaitForElementInvisible(this AppiumDriver driver, string element, Enum locatorType, int timeout = 60)
        {
            WebDriverWait wait = new(driver, TimeSpan.FromSeconds(timeout));
            By locator = locatorType switch
            {
                Locator.LocatorType.XPath => By.XPath(element),
                Locator.LocatorType.Id => By.Id(element),
                Locator.LocatorType.AccessibilityId => MobileBy.AccessibilityId(element),
                Locator.LocatorType.Name => By.Name(element),
                Locator.LocatorType.ClassName => By.ClassName(element),
                Locator.LocatorType.CssSelector => By.CssSelector(element),
                Locator.LocatorType.LinkText => By.LinkText(element),
                Locator.LocatorType.PartialLinkText => By.PartialLinkText(element),
                Locator.LocatorType.TagName => By.TagName(element),
                _ => throw new ArgumentOutOfRangeException($"No such locator type: {locatorType}")
            };
            wait.Until(ExpectedConditions.InvisibilityOfElementLocated(locator));
        }

        /// <summary>
        /// Wait for the element to be invisible
        /// </summary>
        /// <param name="driver">The current appium driver instance</param>
        /// <param name="element">The lazy string locator value of the element whose invisibility is being checked</param>
        /// <param name="locatorType">The locator type enum value for locating the element</param>
        /// <param name="timeout">The timeout for the element to be invisible</param>
        /// <exception cref="ArgumentOutOfRangeException">No such locator type is specified in the enum</exception>
        public static void WaitForElementInvisible(this AppiumDriver driver, Lazy<string> element, Enum locatorType, int timeout = 60)
        {
            WebDriverWait wait = new(driver, TimeSpan.FromSeconds(timeout));
            By locator = locatorType switch
            {
                Locator.LocatorType.XPath => By.XPath(element.Value),
                Locator.LocatorType.Id => By.Id(element.Value),
                Locator.LocatorType.AccessibilityId => MobileBy.AccessibilityId(element.Value),
                Locator.LocatorType.Name => By.Name(element.Value),
                Locator.LocatorType.ClassName => By.ClassName(element.Value),
                Locator.LocatorType.CssSelector => By.CssSelector(element.Value),
                Locator.LocatorType.LinkText => By.LinkText(element.Value),
                Locator.LocatorType.PartialLinkText => By.PartialLinkText(element.Value),
                Locator.LocatorType.TagName => By.TagName(element.Value),
                _ => throw new ArgumentOutOfRangeException($"No such locator type: {locatorType}")
            };
            wait.Until(ExpectedConditions.InvisibilityOfElementLocated(locator));
        }

        /// <summary>
        /// Sets the implicit wait timeout for the driver instance
        /// </summary>
        /// <param name="driver">The current appium driver instance</param>
        /// <param name="timeout">The timeout for the driver to wait</param>
        public static void ImplicitlyWait(this AppiumDriver driver, int timeout = 60)
        {
            driver.Manage().Timeouts().ImplicitWait = TimeSpan.FromSeconds(timeout);
        }

        /// <summary>
        /// Is element exists
        /// </summary>
        /// <param name="driver">The current appium driver instance</param>
        /// <param name="element">The string locator value of the element whose existence is being checked</param>
        /// <param name="locatorType">The locator type enum value for locating the element</param>
        /// <exception cref="ArgumentOutOfRangeException">No such locator type is specified in the enum</exception>
        /// <returns>Whether the element is present in the DOM</returns>
        public static bool IsElementExists(this AppiumDriver driver, string element, Enum locatorType)
        {
            try
            {
                AppiumElement locator = locatorType switch
                {
                    Locator.LocatorType.XPath => driver.FindElement(By.XPath(element)),
                    Locator.LocatorType.Id => driver.FindElement(By.Id(element)),
                    Locator.LocatorType.AccessibilityId => driver.FindElement(MobileBy.AccessibilityId(element)),
                    Locator.LocatorType.Name => driver.FindElement(By.Name(element)),
                    Locator.LocatorType.ClassName => driver.FindElement(By.ClassName(element)),
                    Locator.LocatorType.CssSelector => driver.FindElement(By.CssSelector(element)),
                    Locator.LocatorType.LinkText => driver.FindElement(By.LinkText(element)),
                    Locator.LocatorType.PartialLinkText => driver.FindElement(By.PartialLinkText(element)),
                    Locator.LocatorType.TagName => driver.FindElement(By.TagName(element)),
                    _ => throw new ArgumentOutOfRangeException($"No such locator type: {locatorType}"),
                };
                return true;
            }
            catch (Exception)
            {
                return false;
            }
        }

        /// <summary>
        /// Is element exists
        /// </summary>
        /// <param name="driver">The current appium driver instance</param>
        /// <param name="element">The lazy string locator value of the element whose existence is being checked</param>
        /// <param name="locatorType">The locator type enum value for locating the element</param>
        /// <exception cref="ArgumentOutOfRangeException">No such locator type is specified in the enum</exception>
        /// <returns>Whether the element is present in the DOM</returns>
        public static bool IsElementExists(this AppiumDriver driver, Lazy<string> element, Enum locatorType)
        {
            try
            {
                AppiumElement locator = locatorType switch
                {
                    Locator.LocatorType.XPath => driver.FindElement(By.XPath(element.Value)),
                    Locator.LocatorType.Id => driver.FindElement(By.Id(element.Value)),
                    Locator.LocatorType.AccessibilityId => driver.FindElement(MobileBy.AccessibilityId(element.Value)),
                    Locator.LocatorType.Name => driver.FindElement(By.Name(element.Value)),
                    Locator.LocatorType.ClassName => driver.FindElement(By.ClassName(element.Value)),
                    Locator.LocatorType.CssSelector => driver.FindElement(By.CssSelector(element.Value)),
                    Locator.LocatorType.LinkText => driver.FindElement(By.LinkText(element.Value)),
                    Locator.LocatorType.PartialLinkText => driver.FindElement(By.PartialLinkText(element.Value)),
                    Locator.LocatorType.TagName => driver.FindElement(By.TagName(element.Value)),
                    _ => throw new ArgumentOutOfRangeException($"No such locator type: {locatorType}"),
                };
                return true;
            }
            catch (Exception)
            {
                return false;
            }
        }

        /// <summary>
        /// Is element displayed
        /// </summary>
        /// <param name="driver">The current appium driver instance</param>
        /// <param name="element">The string locator value of the element whose visibility is being checked</param>
        /// <param name="locatorType">The locator type enum value for locating the element</param>
        /// <exception cref="ArgumentOutOfRangeException">No such locator type is specified in the enum</exception>
        /// <returns>Whether the element is displayed in the UI</returns>
        public static bool IsElementDisplayed(this AppiumDriver driver, string element, Enum locatorType)
        {
            try
            {
                bool isDisplayed = locatorType switch
                {
                    Locator.LocatorType.XPath => driver.FindElement(By.XPath(element)).Displayed,
                    Locator.LocatorType.Id => driver.FindElement(By.Id(element)).Displayed,
                    Locator.LocatorType.AccessibilityId => driver.FindElement(MobileBy.AccessibilityId(element)).Displayed,
                    Locator.LocatorType.Name => driver.FindElement(By.Name(element)).Displayed,
                    Locator.LocatorType.ClassName => driver.FindElement(By.ClassName(element)).Displayed,
                    Locator.LocatorType.CssSelector => driver.FindElement(By.CssSelector(element)).Displayed,
                    Locator.LocatorType.LinkText => driver.FindElement(By.LinkText(element)).Displayed,
                    Locator.LocatorType.PartialLinkText => driver.FindElement(By.PartialLinkText(element)).Displayed,
                    Locator.LocatorType.TagName => driver.FindElement(By.TagName(element)).Displayed,
                    _ => throw new ArgumentOutOfRangeException($"No such locator type: {locatorType}"),
                };
                return isDisplayed;
            }
            catch (Exception)
            {
                return false;
            }
        }

        /// <summary>
        /// Is element displayed
        /// </summary>
        /// <param name="driver">The current appium driver instance</param>
        /// <param name="element">The lazy string locator value of the element whose visibility is being checked</param>
        /// <param name="locatorType">The locator type enum value for locating the element</param>
        /// <exception cref="ArgumentOutOfRangeException">No such locator type is specified in the enum</exception>
        /// <returns></returns>
        public static bool IsElementDisplayed(this AppiumDriver driver, Lazy<string> element, Enum locatorType)
        {
            try
            {
                bool isDisplayed = locatorType switch
                {
                    Locator.LocatorType.XPath => driver.FindElement(By.XPath(element.Value)).Displayed,
                    Locator.LocatorType.Id => driver.FindElement(By.Id(element.Value)).Displayed,
                    Locator.LocatorType.AccessibilityId => driver.FindElement(MobileBy.AccessibilityId(element.Value)).Displayed,
                    Locator.LocatorType.Name => driver.FindElement(By.Name(element.Value)).Displayed,
                    Locator.LocatorType.ClassName => driver.FindElement(By.ClassName(element.Value)).Displayed,
                    Locator.LocatorType.CssSelector => driver.FindElement(By.CssSelector(element.Value)).Displayed,
                    Locator.LocatorType.LinkText => driver.FindElement(By.LinkText(element.Value)).Displayed,
                    Locator.LocatorType.PartialLinkText => driver.FindElement(By.PartialLinkText(element.Value)).Displayed,
                    Locator.LocatorType.TagName => driver.FindElement(By.TagName(element.Value)).Displayed,
                    _ => throw new ArgumentOutOfRangeException($"No such locator type: {locatorType}"),
                };
                return isDisplayed;
            }
            catch (Exception)
            {
                return false;
            }
        }

        /// <summary>
        /// Drag and drop
        /// </summary>
        /// <param name="driver">The current appium driver instance</param>
        /// <param name="source">The element to be moved</param>
        /// <param name="target">The element to which the source element is moved</param>
        public static void DragAndDrop(this AppiumDriver driver, AppiumElement source, AppiumElement target)
        {
            Actions actions = new(driver);
            actions.DragAndDrop(source, target)
                .Build()
                .Perform();
        }

        /// <summary>
        /// Drag and drop
        /// </summary>
        /// <param name="driver">The current appium driver instance</param>
        /// <param name="source">The element to be moved</param>
        /// <param name="target">The element to which the source element is moved</param>
        public static void DragAndDrop(this AppiumDriver driver, Lazy<AppiumElement> source, Lazy<AppiumElement> target)
        {
            Actions actions = new(driver);
            actions.DragAndDrop(source.Value, target.Value)
                .Build()
                .Perform();
        }

        /// <summary>
        /// Drag and drop with offset
        /// </summary>
        /// <param name="driver">The current appium driver instance</param>
        /// <param name="source">The element to be moved</param>
        /// <param name="offsetX">The x coordinate distance to be moved</param>
        /// <param name="offsetY">The y coordinate distance to be moved</param>
        public static void DragAndDrop(this AppiumDriver driver, AppiumElement source, int offsetX, int offsetY)
        {
            Actions actions = new(driver);
            actions.Click(source).MoveByOffset(offsetX, offsetY).Release()
                .Build()
                .Perform();
        }

        /// <summary>
        /// Drag and drop with offset
        /// </summary>
        /// <param name="driver">The current appium driver instance</param>
        /// <param name="source">The element to be moved</param>
        /// <param name="offsetX">The x coordinate distance to be moved</param>
        /// <param name="offsetY">The y coordinate distance to be moved</param>
        public static void DragAndDrop(this AppiumDriver driver, Lazy<AppiumElement> source, int offsetX, int offsetY)
        {
            Actions actions = new(driver);
            actions.Click(source.Value).MoveByOffset(offsetX, offsetY).Release()
                .Build()
                .Perform();
        }

        /// <summary>
        /// Move to element and click
        /// </summary>
        /// <param name="driver">The current appium driver instance</param>
        /// <param name="element">The element to be moved</param>
        public static void MoveToElementAndClick(this AppiumDriver driver, AppiumElement element)
        {
            Actions actions = new(driver);
            actions.MoveToElement(element).Click().Perform();
        }

        /// <summary>
        /// Move to element and click
        /// </summary>
        /// <param name="driver">The current appium driver instance</param>
        /// <param name="element">The element to be moved</param>
        public static void MoveToElementAndClick(this AppiumDriver driver, Lazy<AppiumElement> element)
        {
            Actions actions = new(driver);
            actions.MoveToElement(element.Value).Click().Perform();
        }

        /// <summary>
        /// Mouse hover an element
        /// </summary>
        /// <param name="driver">The current appium driver instance</param>
        /// <param name="element">The element to be mouse hovered</param>
        public static void MouseHover(this AppiumDriver driver, AppiumElement element)
        {
            Actions actions = new(driver);
            actions.MoveToElement(element).Perform();
        }

        /// <summary>
        /// Mouse hover an element
        /// </summary>
        /// <param name="driver">The current appium driver instance</param>
        /// <param name="element">The element to be mouse hovered</param>
        public static void MouseHover(this AppiumDriver driver, Lazy<AppiumElement> element)
        {
            Actions actions = new(driver);
            actions.MoveToElement(element.Value).Perform();
        }

        /// <summary>
        /// Double click an element
        /// </summary>
        /// <param name="driver">The current appium driver instance</param>
        /// <param name="element">The element to be clicked</param>
        public static void DoubleClick(this AppiumDriver driver, AppiumElement element)
        {
            Actions actions = new(driver);
            actions.DoubleClick(element).Perform();
        }

        /// <summary>
        /// Double click an element
        /// </summary>
        /// <param name="driver">The current appium driver instance</param>
        /// <param name="element">The element to be clicked</param>
        public static void DoubleClick(this AppiumDriver driver, Lazy<AppiumElement> element)
        {
            Actions actions = new(driver);
            actions.DoubleClick(element.Value).Perform();
        }

        /// <summary>
        /// Send keys using actions class
        /// </summary>
        /// <param name="driver">The current appium driver instance</param>
        /// <param name="element">The element to be interacted</param>
        /// <param name="keysToSend">Keys to send</param>
        public static void SendKeysUsingActions(this AppiumDriver driver, AppiumElement element, string keysToSend)
        {
            Actions actions = new(driver);
            actions.SendKeys(element, keysToSend).Perform();
        }

        /// <summary>
        /// Send keys using actions class
        /// </summary>
        /// <param name="driver">The current appium driver instance</param>
        /// <param name="element">The element to be interacted</param>
        /// <param name="keysToSend">Keys to send</param>
        public static void SendKeysUsingActions(this AppiumDriver driver, Lazy<AppiumElement> element, string keysToSend)
        {
            Actions actions = new(driver);
            actions.SendKeys(element.Value, keysToSend).Perform();
        }

        /// <summary>
        /// Locate an element
        /// </summary>
        /// <param name="driver">The current appium driver instance</param>
        /// <param name="elementToLocate">The element to be located</param>
        /// <param name="locatorType">The locator type enum value for locating the element</param>
        /// <returns>The located element</returns>
        /// <exception cref="ArgumentOutOfRangeException">No such locator type is specified in the enum</exception>
        public static AppiumElement LocateElement(this AppiumDriver driver, string elementToLocate, Enum locatorType)
        {
            AppiumElement element = locatorType switch
            {
                Locator.LocatorType.XPath => driver.FindElement(By.XPath(elementToLocate)),
                Locator.LocatorType.Id => driver.FindElement(By.Id(elementToLocate)),
                Locator.LocatorType.AccessibilityId => driver.FindElement(MobileBy.AccessibilityId(elementToLocate)),
                Locator.LocatorType.Name => driver.FindElement(By.Name(elementToLocate)),
                Locator.LocatorType.ClassName => driver.FindElement(By.ClassName(elementToLocate)),
                Locator.LocatorType.CssSelector => driver.FindElement(By.CssSelector(elementToLocate)),
                Locator.LocatorType.LinkText => driver.FindElement(By.LinkText(elementToLocate)),
                Locator.LocatorType.PartialLinkText => driver.FindElement(By.PartialLinkText(elementToLocate)),
                Locator.LocatorType.TagName => driver.FindElement(By.TagName(elementToLocate)),
                _ => throw new ArgumentOutOfRangeException($"No such locator type: {locatorType}"),
            };
            return element;
        }

        /// <summary>
        /// Locate an element
        /// </summary>
        /// <param name="driver">The current appium driver instance</param>
        /// <param name="elementToLocate">The element to be located</param>
        /// <param name="locatorType">The locator type enum value for locating the element</param>
        /// <exception cref="ArgumentOutOfRangeException">No such locator type is specified in the enum</exception>
        /// <returns>The located element</returns>
        public static AppiumElement LocateElement(this AppiumDriver driver, Lazy<string> elementToLocate, Enum locatorType)
        {
            AppiumElement element = locatorType switch
            {
                Locator.LocatorType.XPath => driver.FindElement(By.XPath(elementToLocate.Value)),
                Locator.LocatorType.Id => driver.FindElement(By.Id(elementToLocate.Value)),
                Locator.LocatorType.AccessibilityId => driver.FindElement(MobileBy.AccessibilityId(elementToLocate.Value)),
                Locator.LocatorType.Name => driver.FindElement(By.Name(elementToLocate.Value)),
                Locator.LocatorType.ClassName => driver.FindElement(By.ClassName(elementToLocate.Value)),
                Locator.LocatorType.CssSelector => driver.FindElement(By.CssSelector(elementToLocate.Value)),
                Locator.LocatorType.LinkText => driver.FindElement(By.LinkText(elementToLocate.Value)),
                Locator.LocatorType.PartialLinkText => driver.FindElement(By.PartialLinkText(elementToLocate.Value)),
                Locator.LocatorType.TagName => driver.FindElement(By.TagName(elementToLocate.Value)),
                _ => throw new ArgumentOutOfRangeException($"No such locator type: {locatorType}"),
            };
            return element;
        }

        /// <summary>
        /// Get all elements into list
        /// </summary>
        /// <param name="driver">The current appium driver instance</param>
        /// <param name="element">The string value of the element to be located</param>
        /// <returns>The list of located elements</returns>
        public static IList<AppiumElement> GetAllElementsIntoList(this AppiumDriver driver, string element)
        {
            return driver.FindElements(By.XPath(element));
        }

        /// <summary>
        /// Get all elements into list
        /// </summary>
        /// <param name="driver">The current appium driver instance</param>
        /// <param name="element">The lazy string value of the element to be located</param>
        /// <returns>The list of located elements</returns>
        public static IList<AppiumElement> GetAllElementsIntoList(this AppiumDriver driver, Lazy<string> element)
        {
            return driver.FindElements(By.XPath(element.Value));
        }

        /// <summary>
        /// Is horizontal scroll present
        /// </summary>
        /// <param name="driver">The current appium driver instance</param>
        /// <returns>Whether or not horizontal scroll bar is present in the page</returns>
        public static bool IsHorizonalScrollPresent(this AppiumDriver driver)
        {
            IJavaScriptExecutor javaScriptExecutor = (IJavaScriptExecutor)driver;
            return (bool)javaScriptExecutor.ExecuteScript("return document.documentElement.scrollWidth>document.documentElement.clientWidth;");
        }

        /// <summary>
        /// Is vertical scroll present
        /// </summary>
        /// <param name="driver">The current appium driver instance</param>
        /// <returns>Whether or not vertical scroll bar is present in the page</returns>
        public static bool IsVerticalScrollPresent(this AppiumDriver driver)
        {
            IJavaScriptExecutor javaScriptExecutor = (IJavaScriptExecutor)driver;
            return (bool)javaScriptExecutor.ExecuteScript("return document.documentElement.scrollHeight>document.documentElement.clientHeight;");
        }

        /// <summary>
        /// Javascript scroll into webelement view
        /// </summary>
        /// <param name="driver">The current appium driver instance</param>
        /// <param name="element">The element on which the scroll is needed</param>
        public static void JavascriptScrollIntoWebelementView(this AppiumDriver driver, AppiumElement element)
        {
            IJavaScriptExecutor javaScriptExecutor = (IJavaScriptExecutor)driver;
            javaScriptExecutor.ExecuteScript("arguments[0].scrollIntoView(true);", element);
        }

        /// <summary>
        /// Javascript scroll into webelement view
        /// </summary>
        /// <param name="driver">The current appium driver instance</param>
        /// <param name="element">The element on which the scroll is needed</param>
        public static void JavascriptScrollIntoWebelementView(this AppiumDriver driver, Lazy<AppiumElement> element)
        {
            IJavaScriptExecutor javaScriptExecutor = (IJavaScriptExecutor)driver;
            javaScriptExecutor.ExecuteScript("arguments[0].scrollIntoView(true);", element.Value);
        }

        /// <summary>
        /// Javascript scroll to top
        /// </summary>
        /// <param name="driver">The current appium driver instance</param>
        public static void JavascriptScrollToTop(this AppiumDriver driver)
        {
            IJavaScriptExecutor javaScriptExecutor = (IJavaScriptExecutor)driver;
            javaScriptExecutor.ExecuteScript("scroll(0,0)");
            javaScriptExecutor.ExecuteScript("window.scrollTo(0,0)");
        }

        /// <summary>
        /// Scroll to bottom
        /// </summary>
        /// <param name="driver">The current appium driver instance</param>
        public static void ScrollToBottom(this AppiumDriver driver)
        {
            IJavaScriptExecutor javaScriptExecutor = (IJavaScriptExecutor)driver;
            javaScriptExecutor.ExecuteScript("window.scrollTo(0, document.body.scrollHeight)");
        }

        /// <summary>
        /// Scroll to bottom
        /// </summary>
        /// <param name="driver">The current appium driver instance</param>
        /// <param name="x">The x coordinate value to be scrolled</param>
        public static void ScrollToBottom(this AppiumDriver driver, int x)
        {
            IJavaScriptExecutor javaScriptExecutor = (IJavaScriptExecutor)driver;
            javaScriptExecutor.ExecuteScript("window.scrollTo(document.body.scrollLeft, " + x + ")");
        }

        /// <summary>
        /// Scroll to left
        /// </summary>
        /// <param name="driver">The current appium driver instance</param>
        public static void ScrollToLeft(this AppiumDriver driver)
        {
            IJavaScriptExecutor javaScriptExecutor = (IJavaScriptExecutor)driver;
            javaScriptExecutor.ExecuteScript("window.scrollTo(0, document.body.scrollTop)");
        }

        /// <summary>
        /// Scroll to right
        /// </summary>
        /// <param name="driver">The current appium driver instance</param>
        public static void ScrollToRight(this AppiumDriver driver)
        {
            IJavaScriptExecutor javaScriptExecutor = (IJavaScriptExecutor)driver;
            javaScriptExecutor.ExecuteScript("window.scrollTo(document.body.scrollWidth, document.body.scrollTop)");
        }

        /// <summary>
        /// Scroll to right
        /// </summary>
        /// <param name="driver">The current appium driver instance</param>
        /// <param name="x">The x coordinate value to be scrolled</param>
        public static void ScrollToRight(this AppiumDriver driver, int x)
        {
            IJavaScriptExecutor javaScriptExecutor = (IJavaScriptExecutor)driver;
            javaScriptExecutor.ExecuteScript("window.scrollTo(" + x + ", document.body.scrollTop)");
        }

        /// <summary>
        /// Javascript click
        /// </summary>
        /// <param name="driver">The current appium driver instance</param>
        /// <param name="element">The element on which the click to be performed</param>
        public static void JavascriptClick(this AppiumDriver driver, AppiumElement element)
        {
            IJavaScriptExecutor javaScriptExecutor = (IJavaScriptExecutor)driver;
            javaScriptExecutor.ExecuteScript("arguments[0].click();", element);
        }

        /// <summary>
        /// Javascript click
        /// </summary>
        /// <param name="driver">The current appium driver instance</param>
        /// <param name="element">The element on which the click to be performed</param>
        public static void JavascriptClick(this AppiumDriver driver, Lazy<AppiumElement> element)
        {
            IJavaScriptExecutor javaScriptExecutor = (IJavaScriptExecutor)driver;
            javaScriptExecutor.ExecuteScript("arguments[0].click();", element.Value);
        }

        /// <summary>
        /// Clear text using javascript executor
        /// </summary>
        /// <param name="driver">The current appium driver instance</param>
        /// <param name="element">The element on which the clear to be performed</param>
        public static void ClearTextUsingJavascriptExecutor(this AppiumDriver driver, AppiumElement element)
        {
            IJavaScriptExecutor javaScriptExecutor = (IJavaScriptExecutor)driver;
            javaScriptExecutor.ExecuteScript("arguments[0].value = '';", element);
        }

        /// <summary>
        /// Clear text using javascript executor
        /// </summary>
        /// <param name="driver">The current appium driver instance</param>
        /// <param name="element">The element on which the clear to be performed</param>
        public static void ClearTextUsingJavascriptExecutor(this AppiumDriver driver, Lazy<AppiumElement> element)
        {
            IJavaScriptExecutor javaScriptExecutor = (IJavaScriptExecutor)driver;
            javaScriptExecutor.ExecuteScript("arguments[0].value = '';", element.Value);
        }

        /// <summary>
        /// Clear text using back space
        /// </summary>
        /// <param name="driver">The current appium driver instance</param>
        /// <param name="element">The element on which the clear to be performed</param>
        /// <param name="numberOfCharacters">Number of characters to be cleared</param>
        public static void ClearTextUsingBackSpace(this AppiumDriver driver, AppiumElement element, int numberOfCharacters)
        {
            for (int count = 1; count <= numberOfCharacters; count++)
            {
                element.SendKeys(Keys.Backspace);
            }
        }

        /// <summary>
        /// Clear text using back space
        /// </summary>
        /// <param name="driver">The current appium driver instance</param>
        /// <param name="element">The element on which the clear to be performed</param>
        /// <param name="numberOfCharacters"Number of characters to be cleared></param>
        public static void ClearTextUsingBackSpace(this AppiumDriver driver, Lazy<AppiumElement> element, int numberOfCharacters)
        {
            for (int count = 1; count <= numberOfCharacters; count++)
            {
                element.Value.SendKeys(Keys.Backspace);
            }
        }

        /// <summary>
        /// Set focus on an element
        /// </summary>
        /// <param name="driver">The current appium driver instance</param>
        /// <param name="element">The element on which the focus to be set</param>
        public static void SetFocusOnAnElement(this AppiumDriver driver, AppiumElement element)
        {
            IJavaScriptExecutor javaScriptExecutor = (IJavaScriptExecutor)driver;
            javaScriptExecutor.ExecuteScript("arguments[0].focus();", element);
        }

        /// <summary>
        /// Set focus on an element
        /// </summary>
        /// <param name="driver">The current appium driver instance</param>
        /// <param name="element">The element on which the focus to be set</param>
        public static void SetFocusOnAnElement(this AppiumDriver driver, Lazy<AppiumElement> element)
        {
            IJavaScriptExecutor javaScriptExecutor = (IJavaScriptExecutor)driver;
            javaScriptExecutor.ExecuteScript("arguments[0].focus();", element.Value);
        }

        /// <summary>
        /// Generate locator
        /// </summary>
        /// <param name="driver">The current appium driver instance</param>
        /// <param name="dynamicLocator">The string locator value containing 'replacer' part</param>
        /// <param name="replaceValue">The dynamic value which will replace the 'replacer'</param>
        /// <param name="locatorType">The locator type enum value for locating the element</param>
        /// <returns>Web element generated using specified locator type</returns>
        public static AppiumElement GenerateLocator(this AppiumDriver driver, string dynamicLocator, string replaceValue, Enum locatorType)
        {
            return driver.LocateElement(dynamicLocator.Replace("replacer", replaceValue), locatorType);
        }

        /// <summary>
        /// Generate locator
        /// </summary>
        /// <param name="driver">The current appium driver instance</param>
        /// <param name="dynamicLocator">The lazy string locator value containing 'replacer' part</param>
        /// <param name="replaceValue">The dynamic value which will replace the 'replacer'</param>
        /// <param name="locatorType">The locator type enum value for locating the element</param>
        /// <returns>Web element generated using specified locator type</returns>
        public static AppiumElement GenerateLocator(this AppiumDriver driver, Lazy<string> dynamicLocator, string replaceValue, Enum locatorType)
        {
            return driver.LocateElement(dynamicLocator.Value.Replace("replacer", replaceValue), locatorType);
        }

        /// <summary>
        /// Generate locator
        /// </summary>
        /// <param name="driver">The current appium driver instance</param>
        /// <param name="dynamicLocator">The string locator value containing 'replacer' part</param>
        /// <param name="replaceValue">The list of dynamic value which will replace the 'replacer'</param>
        /// <param name="locatorType">The locator type enum value for locating the element</param>
        /// <returns>Web element generated using specified locator type</returns>
        public static AppiumElement GenerateLocator(this AppiumDriver driver, string dynamicLocator, List<string> replaceValue, Enum locatorType)
        {
            for (int i = 1; i <= replaceValue.Count; i++)
            {
                dynamicLocator = dynamicLocator.Replace("replacer" + i, replaceValue[i - 1]);
            }
            return driver.LocateElement(dynamicLocator, locatorType);
        }

        /// <summary>
        /// Generate locator
        /// </summary>
        /// <param name="driver">The current appium driver instance</param>
        /// <param name="dynamicLocator">The lazy string locator value containing 'replacer' part</param>
        /// <param name="replaceValue">The list of dynamic value which will replace the 'replacer'</param>
        /// <param name="locatorType">The locator type enum value for locating the element</param>
        /// <returns>Web element generated using specified locator type</returns>
        public static AppiumElement GenerateLocator(this AppiumDriver driver, Lazy<string> dynamicLocator, List<string> replaceValue, Enum locatorType)
        {
            String newLocator = dynamicLocator.Value;
            for (int i = 1; i <= replaceValue.Count; i++)
            {
                newLocator = newLocator.Replace("replacer" + i, replaceValue[i - 1]);
            }
            return driver.LocateElement(newLocator, locatorType);
        }

        /// <summary>
        /// Generate locators into list
        /// </summary>
        /// <param name="driver">The current appium driver instance</param>
        /// <param name="dynamicLocator">The string locator value containing 'replacer' part</param>
        /// <param name="replaceValue">The dynamic value which will replace the 'replacer'</param>
        /// <returns>The list of web element generated using specified locator type</returns>
        public static IList<AppiumElement> GenerateLocatorsIntoList(this AppiumDriver driver, string dynamicLocator, string replaceValue)
        {
            return driver.GetAllElementsIntoList(dynamicLocator.Replace("replacer", replaceValue));
        }


        /// <summary>
        /// Generate locators into list
        /// </summary>
        /// <param name="driver">The current appium driver instance</param>
        /// <param name="dynamicLocator">The lazy string locator value containing 'replacer' part</param>
        /// <param name="replaceValue">The dynamic value which will replace the 'replacer'</param>
        /// <returns>The list of web element generated using specified locator type</returns>
        public static IList<AppiumElement> GenerateLocatorsIntoList(this AppiumDriver driver, Lazy<string> dynamicLocator, string replaceValue)
        {
            return driver.GetAllElementsIntoList(dynamicLocator.Value.Replace("replacer", replaceValue));
        }

        /// <summary>
        /// Confirm the alert pop up
        /// </summary>
        /// <param name="driver">The current appium driver instance</param>
        public static void ConfirmAlert(this AppiumDriver driver)
        {
            driver.SwitchTo().Alert().Accept();
            driver.SwitchTo().DefaultContent();
        }

        /// <summary>
        /// Dismiss the alert pop up
        /// </summary>
        /// <param name="driver">The current appium driver instance</param>
        public static void DismissAlert(this AppiumDriver driver)
        {
            driver.SwitchTo().Alert().Dismiss();
            driver.SwitchTo().DefaultContent();
        }

        /// <summary>
        /// Capture Screenshot of the driver and save it in ./bin/Debug/net6.0/Attachments
        /// <example><code>
        /// #How to use it: 
        /// driver.CaptureScreenshots();
        /// </code></example>
        /// </summary>
        /// <param name="driver">The AppiumDriver instance calling this method</param>
        public static string CaptureScreenshots(this AppiumDriver driver)
        {
            var directoryPath = Directory.GetParent(Assembly.GetExecutingAssembly().Location)!
                .Parent!
                .Parent!
                .Parent!
                .FullName + $"{Path.DirectorySeparatorChar}bin{Path.DirectorySeparatorChar}Debug{Path.DirectorySeparatorChar}net6.0{Path.DirectorySeparatorChar}Attachments{Path.DirectorySeparatorChar}";

            return driver.CaptureScreenshots(directoryPath);
        }

        /// <summary>
        /// Capture Screenshot of the driver and save it in given directory path
        /// <example><code>
        /// #How to use it: 
        /// driver.CaptureScreenshots("/directoryPath");
        /// </code></example>
        /// </summary>
        /// <param name="driver">The AppiumDriver instance calling this method</param>
        public static string CaptureScreenshots(this AppiumDriver driver, string directoryPath)
        {
            var screenshot = ((ITakesScreenshot)driver).GetScreenshot();
            if (!Directory.Exists(directoryPath))
            {
                Directory.CreateDirectory(directoryPath);
            }
            var path = directoryPath + TestContext.CurrentContext.Test.MethodName + "_screenshot_" + DateTime.Now.Ticks + ".png";
            screenshot.SaveAsFile(path);
            return path;
        }
    }
}
﻿using NUnit.Framework;
using OpenQA.Selenium.Appium;
using OpenQA.Selenium.Appium.Enums;
using OpenQA.Selenium.Appium.iOS;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TestAutomation.Mobile.Core.ApiCore.Methods;

namespace TestAutomation.Mobile.Core.MobileCore.DriverInitializer
{
    public class IosDriverInitializer : IDriverInitializer
    {
        AppiumDriver? driver;
        AppiumOptions options = new AppiumOptions();
        public AppiumDriver InitializeDriver()
        {
            options.DeviceName = TestContext.Parameters["cloudDeviceName"];
            options.App = BrowserStackService.BrowserStackUploadAppUsingApi();
            options.AutomationName = AutomationName.iOSXcuiTest;
            options.PlatformName = TestContext.Parameters["platformName"];
            options.PlatformVersion = TestContext.Parameters["platformVersion"];
            options.AddAdditionalAppiumOption("build", TestContext.Parameters["buildName"] + DateTime.Now.ToString("yyyy’-‘MM’-‘dd’T’HH’:’mm’:’ss"));
            options.AddAdditionalAppiumOption("name", TestContext.Parameters["sessionName"]);
            options.AddAdditionalAppiumOption("browserstackLocal", true);
            options.AddAdditionalAppiumOption("browserstack.debug", true);
            options.AddAdditionalAppiumOption("browserstack.networkLogs", true);
            return new IOSDriver(new Uri($"http://{TestContext.Parameters["userName"]}:{TestContext.Parameters["password"]}@hub.browserstack.com/wd/hub"), options);
        }
    }
}
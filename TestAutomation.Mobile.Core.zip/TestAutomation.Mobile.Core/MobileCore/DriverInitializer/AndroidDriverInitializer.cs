﻿using NUnit.Framework;
using OpenQA.Selenium;
using OpenQA.Selenium.Appium;
using OpenQA.Selenium.Appium.Android;
using OpenQA.Selenium.Appium.Enums;
using OpenQA.Selenium.Appium.Service;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Sockets;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using TestAutomation.Mobile.Core.ApiCore.Methods;
using TestAutomation.Mobile.Core.MobileCore.Core;
using TestAutomation.Mobile.Core.MobileCore.Utilities;

namespace TestAutomation.Mobile.Core.MobileCore.DriverInitializer
{
    public class AndroidDriverInitializer : IDriverInitializer
    {
        AppiumDriver? _appDriver;
        AppiumOptions options = new AppiumOptions();

        /// <summary>
        /// Initialize driver based on the environment.
        /// </summary>
        public AppiumDriver InitializeDriver()
        {
            ServiceBuilder serviceBuilder = new ServiceBuilder();

            try
            {
                if (TestContext.Parameters["testEnvironment"]!.Equals("local", StringComparison.OrdinalIgnoreCase))
                {
                    serviceBuilder.BuildAppiumService().Start();
                    options.DeviceName = TestContext.Parameters["localDeviceName"];
                    options.App = System.IO.Path.Combine(FileUtils.GetProjectDirectory(), TestContext.Parameters["localApkPath"]!).Replace("\\", "//");
                    options.AutomationName = AutomationName.AndroidUIAutomator2;
                    options.AddAdditionalAppiumOption("newCommandTimeout", 1800000);
                    options.AddAdditionalAppiumOption("appWaitDuration", 60000);
                    _appDriver = new AndroidDriver(new Uri("http://" + SystemUtils.GetLocalIPAddress() + ":" + TestContext.Parameters["appiumPort"] + "/"), options);
                }
                else
                {
                    options.DeviceName = TestContext.Parameters["cloudDeviceName"];
                    options.App = BrowserStackService.BrowserStackUploadAppUsingApi();
                    options.AutomationName = AutomationName.AndroidUIAutomator2;
                    options.PlatformName = TestContext.Parameters["platformName"];
                    options.PlatformVersion = TestContext.Parameters["platformVersion"];
                    options.AddAdditionalAppiumOption("build", TestContext.Parameters["buildName"] + DateTime.Now.ToString("yyyy’-‘MM’-‘dd’T’HH’:’mm’:’ss"));
                    options.AddAdditionalAppiumOption("name", TestContext.Parameters["sessionName"]);
                    options.AddAdditionalAppiumOption("browserstackLocal", true);
                    options.AddAdditionalAppiumOption("browserstack.debug", true);
                    options.AddAdditionalAppiumOption("browserstack.console", "verbose");
                    options.AddAdditionalAppiumOption("browserstack.networkLogs", true);
                    _appDriver = new AndroidDriver(new Uri($"http://{TestContext.Parameters["userName"]}:{TestContext.Parameters["password"]}@hub.browserstack.com/wd/hub"), options);
                }
            }
            catch
            {
                throw new Exception();
            }

            return _appDriver;
        }
    }
}
﻿using OpenQA.Selenium.Appium;
using OpenQA.Selenium.Appium.Android;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TestAutomation.Mobile.Core.MobileCore.DriverInitializer
{
    public interface IDriverInitializer
    {
        AppiumDriver InitializeDriver();
    }
}
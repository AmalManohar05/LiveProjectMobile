﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TestAutomation.Mobile.Core.MobileCore.DriverInitializer;

namespace TestAutomation.Mobile.Core.MobileCore.DriverFactory
{
    public class AndroidDriverFactory : IDriverManagerFactory
    {
        public IDriverInitializer GetDriver()
        {
            return new AndroidDriverInitializer();
        }
    }
}
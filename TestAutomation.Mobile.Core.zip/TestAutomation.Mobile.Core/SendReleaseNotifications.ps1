# Get the directory where the current script is located
$currentScriptDirectory = Split-Path -Path $MyInvocation.MyCommand.Path -Parent

# Set the working directory to the script directory
Set-Location -Path $currentScriptDirectory

# Specify the path to your Directory.Build.props here
$propsFile = "Directory.Build.props"
[xml]$props = Get-Content $propsFile

# Retrieve the PackageVersion from the Directory.Build.props file
$packageVersion = $props.Project.PropertyGroup.PackageVersion
if (-not $packageVersion) {
    Write-Error "Failed to retrieve a valid PackageVersion"
    exit 1
}

# Prepare the payload with the retrieved PackageVersion
$payload = @{
    type = "message"
    attachments = @(
        @{
            contentType = "application/vnd.microsoft.card.adaptive"
            contentUrl = $null
            content = @{
                "$schema" = "http://adaptivecards.io/schemas/adaptive-card.json"
                type = "AdaptiveCard"
                version = "1.5"
                height = "stretch"
                width = "stretch"
                body = @(
                    @{
                        type = "Container"
                        style = "good"
                        height = "stretch"
                        width = "stretch"
                        items = @(
                            @{
                                type = "TextBlock"
                                text = "PACE Mobile Core - New NuGet version has been released"
                                size = "Medium"
                                weight = "Bolder"
                                separator = $true
                                wrap = $true
                                maxLines = 20
                            },
                            @{
                                type = "TextBlock"
                                text = "**Version:** $packageVersion"
                                wrap = $true
                                maxLines = 20
                            },
                            @{
                                type = "TextBlock"
                                text = "**Package:** TestAutomation.Mobile.Core"
                                wrap = $true
                                maxLines = 20
                            },
                            @{
                                type = "TextBlock"
                                text = "**Major Updates:** 'Mobile test automation framework added"
                                wrap = $true
                                maxLines = 20
                            }
                        )
                    }
                )
            }
        }
    )
} | ConvertTo-Json -Depth 10

$uri = "https://pitsolutions.webhook.office.com/webhookb2/dd6510fa-9914-4842-a756-385c36e57d62@192a4d7a-44fa-49f4-b052-b8e88940ae49/IncomingWebhook/866e1129088c4f499bf7c12d2a814501/a8fe8153-a3c6-4795-97fd-0775c0ac2d5e"
$headers = @{
    "Content-Type" = "application/json; charset=utf-8"
}

Invoke-RestMethod -Uri $uri -Method POST -Body $payload -Headers $headers
Write-Host "Sent adaptive card with Package Version $packageVersion"
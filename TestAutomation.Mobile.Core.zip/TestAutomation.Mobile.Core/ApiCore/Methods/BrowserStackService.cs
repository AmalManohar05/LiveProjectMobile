﻿using Newtonsoft.Json.Linq;
using NUnit.Framework;
using System.Net.Http.Headers;
using System.Text;
using TestAutomation.Mobile.Core.MobileCore.Utilities;

namespace TestAutomation.Mobile.Core.ApiCore.Methods
{
    public static class BrowserStackService
    {
        /// <summary>
        /// Browser stack upload app using api.
        /// </summary>
        /// <returns>The app url</returns>
        public static string BrowserStackUploadAppUsingApi()
        {
            HttpClient client = new();
            client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Basic",
                Convert.ToBase64String(Encoding.ASCII.GetBytes($"{TestContext.Parameters["userName"]}:{TestContext.Parameters["password"]}")));
            string localAppPath = TestContext.Parameters["platformName"]!.Equals("android", StringComparison.OrdinalIgnoreCase) ? TestContext.Parameters["localApkPath"]! : TestContext.Parameters["localIpaPath"]!;
            using MultipartFormDataContent form = new()
            {
                {
                    new StreamContent(File.OpenRead(System.IO.Path.Combine(FileUtils.GetProjectDirectory(), localAppPath!).Replace("\\", "//")))
                    {
                        Headers = { ContentType = new MediaTypeHeaderValue("application/octet-stream") }
                    },
                    "file",
                    Path.GetFileName(System.IO.Path.Combine(Environment.CurrentDirectory, localAppPath!))
                }
            };
            return JObject.Parse(client.PostAsync("https://api-cloud.browserstack.com/app-automate/upload", form).Result.Content.ReadAsStringAsync().Result)["app_url"]!.ToString();
        }
    }
}
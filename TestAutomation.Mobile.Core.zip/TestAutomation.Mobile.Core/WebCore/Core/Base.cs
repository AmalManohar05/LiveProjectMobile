﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TestAutomation.Mobile.Core.WebCore.Core
{
    internal class Base
    {
    }
}
